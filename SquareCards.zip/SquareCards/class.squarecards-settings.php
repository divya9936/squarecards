<?php
if (!class_exists('SquareCards_Settings')) {

    class SquareCards_Settings
    {

        public static $options;

        public function __construct()
        {
            self::$options = get_option('squarecards_options');
            add_action('admin_init', array($this, 'admin_init'));
        }

        public function admin_init()
        {
            register_setting('squarecards_group', 'squarecards_options', array($this, 'squarecards_validate'));
            add_settings_section(
                'squarecards_main_section',
                'How does it work?',
                null,
                'squarecards_page1'
            );
            add_settings_section(
                'squarecards_second_section',
                'Other Plugin Options',
                null,
                'squarecards_page2'
            );

            add_settings_field(
                'squarecards_shortcode',
                'Shortcode',
                array($this, 'squarecards_shortcode_callback'),
                'squarecards_page1',
                'squarecards_main_section'

            );
            add_settings_field(
                'squarecards_title',
                'Card Title',
                array($this, 'squarecards_title_callback'),
                'squarecards_page2',
                'squarecards_second_section',
                array(
                    'label_for' => 'squarecards_title'
                )
            );
        }

        public function squarecards_shortcode_callback()
        {
            ?>
            <span>Use the shortcode [squarecards] to display the slider in any page/post/widget</span>
            <?php
        }
        public function squarecards_title_callback($args)
        {
            ?>
            <input type="text" name="squarecards_options[squarecards_title]" id="squarecards_title"
                value="<?php echo isset(self::$options['squarecards_title']) ? esc_attr(self::$options['squarecards_title']) : ''; ?>">
            <?php
        }
        //   to ensure that the data submitted from a settings form 
        //   meets certain criteria before it is saved in the database. 

        public function squarecards_validate($input)
        {
            $new_input = array();
            foreach ($input as $key => $value) {
                switch ($key) {
                    case 'squarecards_title':
                        if (empty($value)) {
                            add_settings_error('squarecards_options', 'squarecards_message', 'The title field can not be left empty', 'error');
                            $value = 'Please, type some text';
                        }
                        $new_input[$key] = sanitize_text_field($value);
                        break;
                    default:
                        $new_input[$key] = sanitize_text_field($value);
                        break;
                }



            }
            return $new_input;
        }
    }
}