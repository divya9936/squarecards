<div class="baseContainer">
      <h1>SOLVING INDUSTRY CHALLENGES</h1>
      <div class="container">
        <div
          class="card active"
          id="firstCard"
          onmouseenter="setImgUrl(this,'active')"
          onmouseleave="setImgUrl(this,'default')"
          data-for="fin"
        >
          <img src="" alt="" />
          <span>Financial Service</span>
        </div>
        <div
          class="card"
          onmouseenter="setImgUrl(this,'active')"
          onmouseleave="setImgUrl(this,'default')"
          data-for="green"
        >
          <img src="" alt="" />
          <span>Agriculture Service</span>
        </div>
        <div
          class="card"
          onmouseenter="setImgUrl(this,'active')"
          onmouseleave="setImgUrl(this,'default')"
          data-for="tool"
        >
          <img src="" alt="" />
          <span>Automotive</span>
        </div>
        <div
          class="card"
          onmouseenter="setImgUrl(this,'active')"
          onmouseleave="setImgUrl(this,'default')"
          data-for="manufacture"
        >
          <img src="" alt="" />
          <span>Manufacturing</span>
        </div>
        <!-- <div
          class="card"
          onmouseenter="setImgUrl(this,'active')"
          onmouseleave="setImgUrl(this,'default')"
          data-for="energy"
        >
          <img src="" alt="" />
          <span>Energy Production</span>
        </div> -->

        <div class="description-wrapper">
          <div class="subdescription hide-desc" id="fin">
            <div class="greenLine"></div>
            <span>
              Deliver digital transformation with an innovation first mindset.
              Transform legacy systems and introduce new approaches that improve
              the overall customer experience, fostering deep loyalty. Leverage
              our unparalleled understanding of evolving market structures and
              regulatory changes to future proof your business.
            </span>
            <a class="learnMore">Learn More</a>
          </div>
          <div class="subdescription hide-desc" id="green">
            <div class="greenLine"></div>
            <span>
              The agricultural industry is riding the wave of digital
              transformation—assisted by technology such as RFID-based sensors,
              drones, and connected farming equipment. Benefits include
              increased production and yields, energy savings,reduced labor
              costs, and better equipment maintenance. It's all made possible by
              leveraging agriculture software solutions.
            </span>
          </div>
          <div class="subdescription hide-desc" id="tool">
            <div class="greenLine"></div>
            <span>
              Industry 4.0 is revolutionizing automotive manufacturers and
              enterprises, giving them a 360-degree view into technical and
              business perspectives. Leverage SoftServe's extensive IoT, AI, ML,
              cloud, and big data analytics experience and expertise to build a
              long-term strategy that drives growth and accelerates digital
              transformation.
            </span>
          </div>
          <div class="subdescription hide-desc" id="manufacture">
            <div class="greenLine"></div>
            <span>
              Become smarter, better, and more innovative to keep up with
              fast-paced changes in manufacturing. Leverage advanced
              technologies like artificial intelligence and machine learning
              (AI/ML) to apply data and deepen efficiency in manufacturing
              processes. Unlock actionable insights to boost productivity and
              reduce costs. Implement industrial internet of things IIoT
              technologies and gain insight into inventory and production.
            </span>
            <a class="learnMore">Learn More</a>
          </div>
          <!-- <div class="subdescription hide-desc" id="energy">
            <div class="greenLine"></div>
            <span>
              Accelerate your digital transformation with actionable insights
              that fuel innovation. Explore our expertise across energy
              subsegments like Oil and Gas and Utilities. See how cutting-edge
              technology can propel your energy organization into more
              sustainable and efficient operations now and into the future.
            </span>
            <a class="learnMore">Learn More</a>
          </div> -->
        </div>
      </div>
    </div>