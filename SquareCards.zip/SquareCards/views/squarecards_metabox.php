<!-- to display the values entered in metaboxes on page refresh -->
<?php
$var_title = get_post_meta($post->ID, 'card_title', true);
$var_desc = get_post_meta($post->ID, 'card_description', true);
$var_active_bg = get_post_meta($post->ID, 'active_background_img', true);
$var_def_bg = get_post_meta($post->ID, 'default_background_img', true);
?>


<!-- fields shown in admin panel -->
<table class="form-table squarecards-metabox">
<input type="hidden" name="squarecards_nonce" value="<?php echo wp_create_nonce( "squarecards_nonce" ); ?>">
    <tr>
        <th>
            <label for="active_background_img">Active Background Image</label>
        </th>
        <td>
            <!-- display preview if image exists -->
            <?php if (!empty($var_active_bg)) : ?>
                <div>
                    <img src="<?php echo esc_url($var_active_bg); ?> " style="max-width: 150px; display: block; margin-bottom:10px;">
                    <span>Image has been uploaded.</span>
                </div>
            <?php endif; ?>
            <input
                type="file"
                name="active_background_img"
                id="active_background_img"
                class="regular-text"
                accept="image/*">
        </td>
    </tr>
    <tr>
        <th>
            <label for="default_background_img">Default Background Image</label>
        </th>
        <td>
            <!-- display preview if image exists -->
            <?php if (!empty($var_def_bg)) : ?>
                <img src="<?php echo esc_url($var_def_bg); ?> " style="max-width: 150px; display: block; margin-bottom:10px;">
            <?php endif; ?>
            <input
                type="file"
                name="default_background_img"
                id="default_background_img"
                class="regular-text"
                accept="image/*">
        </td>
    </tr>
    <tr>
        <th>
            <label for="card_title">Card Title</label>
        </th>
        <td>
            <input
                type="text"
                name="card_title"
                id="card_title"
                class="regular-text"
                value="<?php echo (isset($var_title)) ? esc_html($var_title) : ''; ?>"
                required>
        </td>
    </tr>
    <tr>
        <th>
            <label for="card_description">Description</label>
        </th>
        <td>
            <textarea
                name="card_description"
                id="card_description"
                class="regular-text"
                rows="4"><?php echo (isset($var_desc)) ? esc_html($var_desc) : ''; ?>
        </textarea>
        </td>
    </tr>
</table>