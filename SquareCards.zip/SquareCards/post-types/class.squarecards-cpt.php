<?php

if (!class_exists('SquareCards_Post_Type')) {
    class SquareCards_Post_Type
    {
        function __construct()
        {
            add_action('init', array($this, 'create_post_type'));
            add_action('add_meta_boxes', array($this, 'add_meta_boxes'));
            add_action('save_post', array($this, 'save_post'), 10, 2);
            add_filter('manage_squarecards_posts_columns', array($this, 'squarecards_cpt_columns'));
            add_action( 'manage_squarecards_posts_custom_column', array( $this, 'squarecards_custom_columns'), 10, 2 );
            add_filter( 'manage_edit-squarecards_sortable_columns', array( $this, 'squarecards_sortable_columns' ) );
        }

        public function create_post_type()
        {
            register_post_type(
                'squarecards',
                array(
                    'label' => 'Card',
                    'description'   => 'Cards',
                    'labels' => array(
                        'name'  => 'Cards',
                        'singular_name' => 'Card'
                    ),
                    'public'    => true,
                    'supports'  => array('title', 'editor', 'thumbnail'),
                    'hierarchical'  => false,
                    'show_ui'   => true,
                    'show_in_menu'  => false,//the argument that makes the cpt show up in main admin menu
                    'menu_position' => 5,
                    'show_in_admin_bar' => true,
                    'show_in_nav_menus' => true,
                    'can_export'    => true,
                    'has_archive'   => false,
                    'exclude_from_search'   => false,
                    'publicly_queryable'    => true,
                    'show_in_rest'  => true,
                    'menu_icon' => 'dashicons-images-alt2'
                )
            );
        }
          //  adding columns in the admin area for a cards post type
          public function squarecards_cpt_columns($columns)
          {
              $columns['card_title'] = esc_html__('Card Title', 'squarecards');
              return $columns;
          }
  
          // adding values to the above columns
          public function squarecards_custom_columns( $column, $post_id ){
              switch( $column ){
                  case 'card_title':
                      echo esc_html( get_post_meta( $post_id, 'card_title', true ) );
                  break;             
              }
          }
          //to enable sorting for custom columns
          public function squarecards_sortable_columns( $columns ){
            $columns['card_title'] = 'card_title';
            return $columns;
          }
         
        public function add_meta_boxes()
        {
            add_meta_box(
                'squareCards_meta_box',
                'Link Options',
                array($this, 'add_inner_meta_boxes'),
                'squarecards',
                'normal',
                'high'
            );
        }

        public function add_inner_meta_boxes($post)
        {
            require_once(SquareCards_PATH . 'views/squarecards_metabox.php');
        }

        public function save_post($post_id)
        {
            // nonce validation
            if (isset($_POST['squarecards_nonce'])) {
                if (! wp_verify_nonce($_POST['squarecards_nonce'], 'squarecards_nonce')) {
                    return;
                }
            }
            // autosave check
            if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
                return;
            }
            //post type and permissions check
            if (isset($_POST['post_type']) && $_POST['post_type'] === 'squarecards') {
                if (! current_user_can('edit_page', $post_id)) {
                    return;
                } elseif (! current_user_can('edit_post', $post_id)) {
                    return;
                }
            }
            if (isset($_POST['action']) && $_POST['action'] == 'editpost') {
                $old_title = get_post_meta($post_id, 'card_title', true);
                $new_title = $_POST['card_title'];
                $old_description = get_post_meta($post_id, 'card_description', true);
                $new_description = $_POST['card_description'];


                // Handle the 'active_background_img' file upload. 
                if (!empty($_FILES['active_background_img']['name'])) {
                    $active_img = $_FILES['active_background_img'];
                    $upload = wp_handle_upload($active_img, ['test_form' => false]);

                    if (!isset($upload['error']) && isset($upload['url'])) {
                        update_post_meta($post_id, 'active_background_img', esc_url($upload['url']));
                    }
                }

                // Handle the 'default_background_img' file upload.
                if (!empty($_FILES['default_background_img']['name'])) {
                    $default_img = $_FILES['default_background_img'];
                    $upload = wp_handle_upload($default_img, ['test_form' => false]);

                    if (!isset($upload['error']) && isset($upload['url'])) {
                        update_post_meta($post_id, 'default_background_img', esc_url($upload['url']));
                    }
                }

                if (empty($new_title)) {
                    update_post_meta($post_id, 'card_title', 'Add some text');
                } else {
                    update_post_meta($post_id, 'card_title', sanitize_text_field($new_title), $old_title);
                }

                if (empty($new_description)) {
                    update_post_meta($post_id, 'card_description', 'Add some text');
                } else {
                    update_post_meta($post_id, 'card_description', sanitize_textarea_field($new_description), $old_description);
                }
            }
        }
      

    }
}
