<?php

if (! class_exists('SquareCards_Shortcode')) {
    class SquareCards_Shortcode
    {
        public function __construct()
        {
            add_shortcode('squarecards', array($this, 'add_shortcode'));
        }

        public function add_shortcode($atts = array(), $content = null, $tag = '')
        {

            $atts = array_change_key_case((array) $atts, CASE_LOWER);
//default values for attributes
            extract(shortcode_atts(
                array(
                    'id' => '',
                    'orderby' => 'date'
                ),
                $atts,
                $tag
            ));
            // check if ids passed are integer , if not then delete that one
            if (!empty($id)) {
                $id = array_map('absint', explode(',', $id));
            }

             // Query to fetch custom post types
    $query = new WP_Query(array(
        'post_type' => 'squarecards',
        'posts_per_page' => 4,
    ));

    // Prepare data for cards and descriptions
    $cards = array();
    $descriptions = array();

    if ($query->have_posts()) {
        while ($query->have_posts()) {
            $query->the_post();

            $cards[] = array(
                'title' => get_the_title(),
                'image' => get_the_post_thumbnail_url(),
            );

            $descriptions[] = array(
                'content' => get_the_excerpt(),
                'link' => get_permalink(),
            );
        }
        wp_reset_postdata();
    }

            ob_start(); //starts output buffering
            require(SquareCards_PATH . 'views/squarecards_shortcode.php');
            return ob_get_clean();
        }
    }
}
