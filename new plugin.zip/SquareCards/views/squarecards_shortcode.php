<div class="baseContainer">
  <h1>SOLVING INDUSTRY CHALLENGES</h1>
  <div class="container">
    <?php
    // Query to fetch the cards
    $args = array(
      'post_type' => 'squarecards',
      'posts_per_page' => $atts['posts_per_page'],
      'post_status' => 'publish'
    );
    $my_query = new WP_Query($args);

    // Counter for cards
    $index = 0;

    // Loop through posts
    if ($my_query->have_posts()):
      while ($my_query->have_posts()):
        $my_query->the_post();
        $card_title = get_post_meta(get_the_ID(), 'card_title', true);
        $card_desc = get_post_meta(get_the_ID(), 'card_description', true);
        $active_bg = get_post_meta(get_the_ID(), 'active_background_img', true);
        $def_bg = get_post_meta(get_the_ID(), 'default_background_img', true);
        ?>
        <div class="card <?php echo $index === 0 ? 'active' : ''; ?>" id="card-<?php echo $index + 1; ?>"
          data-index="<?php echo $index; ?>" data-default-bg="<?php echo esc_url($def_bg); ?>"
          data-active-bg="<?php echo esc_url($active_bg); ?>" data-for="desc-<?php echo $index + 1; ?>">
          <img src="<?php echo esc_url($def_bg); ?>" alt="<?php echo esc_attr($card_title); ?>" />
          <span><?php echo esc_html($card_title); ?></span>
        </div>
        <?php
        $index++;
      endwhile;
      wp_reset_postdata();
    endif;
    ?>
  </div>
  <!-- Description section below the cards -->
  <div class="description-wrapper">
    <?php
    // Re-run the query for descriptions, resetting the counter
    $index = 0;
    if ($my_query->have_posts()):
      while ($my_query->have_posts()):
        $my_query->the_post();
        $card_desc = get_post_meta(get_the_ID(), 'card_description', true);
        ?>
        <div class="subdescription <?php echo $index === 0 ? 'visible-desc' : 'hide-desc'; ?>"
          id="desc-<?php echo $index + 1; ?>">
          <div class="greenLine"></div>
          <span><?php echo esc_html($card_desc); ?></span>
        </div>
        <?php
        $index++;
      endwhile;
    endif;
    ?>
  </div>
</div>