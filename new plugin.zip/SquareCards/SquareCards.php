<?php
/*
 Plugin name:Square Cards
 Description:Displays a row of four interactive square cards with color change and text display functionality.
 Version:1.0
 Author:Divya Dixit
 License:GPL v2 or later
 License URL:https://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 Text Domain:SquareCards
 Domain Path:/languages
 */

/*
Square Cards is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
any later version.

Square Cards is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with Square Cards. If not, see {URI to Plugin License}.
*/

/*to prevent someone from accessing the file directly 
https://localhost/mywordpress/wp-content/plugins/squarecards/squarecards.php*/

if (!defined('ABSPATH')) {
    die('bla bla bla');
    exit;
}
if (!class_exists('SquareCards')) {
    class SquareCards
    {
        function __construct()
        {
            //constructor code here
            $this->define_constants();
            //adding menu to admin 
            add_action('admin_menu', array($this, 'add_menu'));
            add_action('wp_enqueue_scripts', array($this, 'my_plugin_enqueue_assets'));

            require_once(SquareCards_PATH . 'post-types/class.squarecards-cpt.php');
            $SquareCards_Post_Type = new SquareCards_Post_Type();
            require_once(SquareCards_PATH . 'class.squarecards-settings.php');
            $SquareCards_Settings = new SquareCards_Settings();
            require_once(SquareCards_PATH . 'shortcodes/class.squarecards-shortcode.php');
            $SquareCards_Shortcode = new SquareCards_Shortcode();
        }
        // defining constants that will be used throughout the plugin 
        public function define_constants()
        {
            define('SquareCards_PATH', plugin_dir_path(__FILE__));
            define('SquareCards_URL', plugin_dir_url(__FILE__));
            define('SquareCards_VERSION', '1.0.0');
        }
        public static function activate()
        {
            update_option('rewrite_rules', '');
        }

        public static function deactivate()
        {
            flush_rewrite_rules();
            unregister_post_type('squarecards');
        }

        // public static function uninstall(){

        // }
        public function add_menu()
        {
            add_menu_page(
                'Square Cards Options',
                'Square Cards',
                'manage_options',
                'squarecards_admin',
                array($this, 'squarecards_settings_page'),
                'dashicons-images-alt2'
            );
            add_submenu_page(
                'squarecards_admin',
                'Manage Cards',
                'Manage Cards',
                'manage_options',
                'edit.php?post_type=squarecards',
                null,
                null
            );

            add_submenu_page(
                'squarecards_admin',
                'Add New Card',
                'Add New Card',
                'manage_options',
                'post-new.php?post_type=squarecards',
                null,
                null
            );
        }

        public function squarecards_settings_page()
        {
            if (!current_user_can('manage_options')) {
                return;
            }
            // display success message if form fields are stored correctly in DB
            if (isset($_GET['settings-updated'])) {
                add_settings_error('squarecards_options', 'squarecards_message', 'Settings Saved', 'success');
            }

            settings_errors('squarecards_options');

            require(SquareCards_PATH . 'views/settings-page.php');
        }
        function my_plugin_enqueue_assets()
        {
            // Define plugin URL
            $plugin_url = plugin_dir_url(__FILE__);

            // Enqueue CSS file
            wp_enqueue_style(
                'my-plugin-style', // Handle
                $plugin_url . 'assets/css/style.css', // Path to the CSS file
                array(), // Dependencies
                '1.0', // Version
                'all' // Media
            );
            wp_register_script(
                'my-plugin-script', // Handle
                plugins_url('assets/js/scripts.js', __FILE__), // Path to the script
                array('jquery'), // Dependencies (if any)
                '1.0', // Version
                true // Load in the footer
            );

            // Localize the script to pass data from PHP to JS (if needed)
            wp_localize_script(
                'my-plugin-script',
                'myPluginData',
                array(
                    'ajax_url' => admin_url('admin-ajax.php'), // Example of dynamic data
                )
            );

            // Enqueue the script
            wp_enqueue_script('my-plugin-script');

        }
    }
}

if (class_exists('SquareCards')) {
    register_activation_hook(__FILE__, array('SquareCards', 'activate'));
    register_deactivation_hook(__FILE__, array('SquareCards', 'deactivate'));
    register_uninstall_hook(__FILE__, array('SquareCards', 'uninstall'));

    $SquareCards = new SquareCards();//instantiating the class
}