
<!-- By adding an index.php file, you can prevent direct access and listing of your plugin files. -->

<?php
#Silence is golden