window.onload = () => {
  console.log("Page loaded");

  const cards = document.querySelectorAll(".card");

  // Ensure all cards show with the default background on page load
  cards.forEach((card) => {
    const defaultBg = card.getAttribute("data-default-bg");
    card.style.backgroundImage = `url(${defaultBg})`; // Set the default background
  });

  // Set the first card to be active
  const firstCard = cards[0];
  firstCard.classList.add("active");
  setImgUrl(firstCard, "active");

  // Get the description for the first card
  const descriptionID = firstCard.getAttribute("data-for");
  const description = document.getElementById(descriptionID);
  if (description) {
    description.classList.remove("hide-desc");
    description.classList.add("visible-desc");
  }

  // Handle hover and click interactions
  cards.forEach((card) => {
    // Hover effect: mouse enter
    card.addEventListener("mouseenter", () => {
      setImgUrl(card, "active");
    });

    // Hover effect: mouse leave
    card.addEventListener("mouseleave", () => {
      if (!card.classList.contains("active")) {
        setImgUrl(card, "default");
      }
    });

    // Click event to toggle the active state
    card.addEventListener("click", () => {
      // Deactivate all other cards and hide their descriptions
      cards.forEach((otherCard) => {
        otherCard.classList.remove("active");
        setImgUrl(otherCard, "default");
        const otherDescription = document.getElementById(
          otherCard.getAttribute("data-for")
        );
        if (otherDescription) {
          otherDescription.classList.remove("visible-desc");
          otherDescription.classList.add("hide-desc");
        }
      });

      // Activate clicked card and show its description
      card.classList.add("active");
      setImgUrl(card, "active");

      const descriptionID = card.getAttribute("data-for");
      const description = document.getElementById(descriptionID);
      if (description) {
        description.classList.remove("hide-desc");
        description.classList.add("visible-desc");
      }
    });
  });
};

// Function to set the background image (active or default)
const setImgUrl = (card, type) => {
  const activeBg = card.getAttribute("data-active-bg"); // Active background
  const defaultBg = card.getAttribute("data-default-bg"); // Default background

  if (type === "active") {
    card.style.backgroundImage = `url(${activeBg})`; // Set active background
  } else {
    card.style.backgroundImage = `url(${defaultBg})`; // Revert to default background
  }
};
