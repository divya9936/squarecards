<?php

if (!class_exists('SquareCards_Shortcode')) {
    class SquareCards_Shortcode
    {
        public function __construct()
        {
            add_shortcode('squarecards', array($this, 'add_shortcode'));
        }

        public function add_shortcode($atts = array(), $content = null, $tag = '')
        {

            $atts = array_change_key_case((array) $atts, CASE_LOWER);
            //default values for attributes
            extract(shortcode_atts(
                array(
                    'category'=>'',
                    'id' => '',
                    'orderby' => 'date'
                ),
                $atts,
                $tag
            ));
            $category = sanitize_text_field($atts['category']);
            // check if ids passed are integer , if not then delete that one
            if (!empty($id)) {
                $id = array_map('absint', explode(',', $id));
            }
            if (!empty( $category)) {
               $args['category-name']=$category;//filters by category
            }


            //          // Query to fetch custom post types
            // $query = new WP_Query(array(
            //     'post_type' => 'squarecards',
            //     'posts_per_page' => 3,
            // ));

            // // Prepare data for cards and descriptions
            // $cards = array();
            // $descriptions = array();

            // if ($query->have_posts()) {
            //     while ($query->have_posts()) {
            //         $query->the_post();

            //         $cards[] = array(
            //             'title' => get_post_meta(get_the_ID(), 'card_title', true),
            //             'active_image' => get_post_meta(get_the_ID(), 'active_background_img', true),
            //             'default_image' => get_post_meta(get_the_ID(), 'default_background_img', true),
            //         );

            //         $descriptions[] = array(
            //             'content' => get_post_meta(get_the_ID(), 'card_description', true),
            //         );
            //     }
            //     wp_reset_postdata();
            // }

            ob_start(); //starts output buffering
            require(SquareCards_PATH . 'views/squarecards_shortcode.php');
            return ob_get_clean();
        }
    }
}